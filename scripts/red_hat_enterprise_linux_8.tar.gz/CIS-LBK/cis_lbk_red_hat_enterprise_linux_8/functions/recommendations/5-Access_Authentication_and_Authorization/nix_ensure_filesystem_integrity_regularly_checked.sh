#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_ensure_filesystem_integrity_regularly_checked.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/15/20    Recommendation "Ensure filesystem integrity is regularly checked"
# Justin Brown		 12/28/22	 Updated to modern format
# Randie Bejar		 11/06/23	 Updated to new version

ensure_filesystem_integrity_regularly_checked()
{
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
   	l_test=""

	
	ensure_filesystem_integrity_regularly_checked_chk()
   	{
		echo -e "- Start check - Ensure filesystem integrity is regularly checked" | tee -a "$LOG" 2>> "$ELOG"
		l_cron_test="" l_systemctl_test=""

		
		if crontab -u root -l | grep -Ers "^([^#]+\s+)?(\/usr\/s?bin\/|^\s*)aide(\.wrapper)?\s(--?\S+\s)*(--(check|update)|\$AIDEARGS)\b" /etc/cron.* /etc/crontab /var/spool/cron/; then
			l_cron_test=passed
		else
			l_cron_test=failed
		fi

		if grep -Eq '^\s*ExecStart=\/usr\/sbin\/aide\s--check\b' /etc/systemd/system/aidecheck.service && grep -Eq '^\s*Unit=aidecheck\.service\b' /etc/systemd/system/aidecheck.timer; then
			systemctl is-enabled aidecheck.service | grep -q enabled && systemctl is-enabled aidecheck.timer | grep -q enabled && l_systemctl_test=passed
		else
			l_systemctl_test=failed		
		fi
		

		if [ "$l_cron_test" = "passed" ] || [ "$l_systemctl_test" = "passed" ]; then
			echo -e "- PASS:\n- Filesystem integrity is being checked" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure filesystem integrity is regularly checked" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		elif [ "$l_cron_test" = "failed" ] && [ "$l_systemctl_test" = "failed" ]; then
			echo -e "- FAIL:\n- Filesystem integrity is NOT being checked" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure filesystem integrity is regularly checked" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi
		
	}

	ensure_filesystem_integrity_regularly_checked_fix()
   	{
      	echo -e "- Start remediation - Ensure filesystem integrity is regularly checked" | tee -a "$LOG" 2>> "$ELOG"
		l_test="manual"
		
		echo -e "- Configure either cron or install and enable aide" | tee -a "$LOG" 2>> "$ELOG"
		echo -e "- End remediation - Ensure filesystem integrity is regularly checked" | tee -a "$LOG" 2>> "$ELOG"
	}

	ensure_filesystem_integrity_regularly_checked_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
		ensure_filesystem_integrity_regularly_checked_fix
		if [ "$l_test" != "manual" ]; then
			ensure_filesystem_integrity_regularly_checked_chk
			if [ "$?" = "101" ]; then
				[ "$l_test" != "failed" ] && l_test="remediated"
			else
				l_test="failed"
			fi
		fi
	fi

   	# Set return code, end recommendation entry in verbose log, and return
   	case "$l_test" in
      	passed)
         	echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
         	return "${XCCDF_RESULT_PASS:-101}"
         	;;
      	remediated)
         	echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
         	return "${XCCDF_RESULT_PASS:-103}"
         	;;
      	manual)
         	echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
         	return "${XCCDF_RESULT_FAIL:-106}"
         	;;
      	NA)
         	echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
         	return "${XCCDF_RESULT_PASS:-104}"
         	;;
      	*)
         	echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
         	return "${XCCDF_RESULT_FAIL:-102}"
         	;;
   	esac
}