#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_repo_gpgcheck_globally_activated.sh
#
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# David Neilson		 05/09/23	 Create for Fedora 34 benchmark
# J Brown			11/20/2023	Updated to test if repo_gpgcheck breaks anything before fixing
#

fed_ensure_repo_gpgcheck_globally_activated()
{
	# Start recommendation entry for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	fed_ensure_repo_gpgcheck_globally_activated_chk()
	{
		l_output="" l_output2=""

		echo -e "- Start check - Ensure repo_gpgcheck is globally activated" | tee -a "$LOG" 2>> "$ELOG"

		# Check the global configuration by running the following command and verify that repo_gpgcheck is set to 1:
		if grep -Pq -- '^\h*repo_gpgcheck\h*=\h*1\b' /etc/dnf/dnf.conf; then
			l_output="- 'repo_gpgcheck=1' found in /etc/dnf/dnf.conf"
		else
			l_output2="- 'repo_gpgcheck=1' NOT found in /etc/dnf/dnf.conf"
		fi

		if [ -z "$l_output2" ]; then
			echo -e "- PASSED:\n$l_output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure repo_gpgcheck is globally activated" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			echo -e "- FAILED:\n$l_output2" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check -Ensure repo_gpgcheck is globally activated" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-102}"
		fi
	}

	fed_ensure_repo_gpgcheck_globally_activated_fix()
	{
		echo -e "- Start remediation - Ensure repo_gpgcheck is globally activated" | tee -a "$LOG" 2>> "$ELOG"

		if dnf --setopt=repo_gpgcheck=1 --assumeno list &> /dev/null; then
			if ! grep -Pq -- '^\h*repo_gpgcheck\h*=\h*1\b' /etc/dnf/dnf.conf; then
				if grep -Eq '^\h*repo_gpgcheck\h*=' /etc/dnf/dnf.conf; then
					echo -e "- Updating repo_gpgcheck value in /etc/dnf/dnf.conf" | tee -a "$LOG" 2>> "$ELOG"
					sed -ri 's/(^\s*repo_gpgcheck\s*)(\s*=\S+)(\s+#.*)?$/\1=1\3/' /etc/dnf/dnf.conf
				else
					echo -e "- Adding repo_gpgcheck value to /etc/dnf/dnf.conf" | tee -a "$LOG" 2>> "$ELOG"
					sed -ri '/\[main\].*/a repo_gpgcheck=1' /etc/dnf/dnf.conf
				fi
			fi
		else
			echo -e "- \"dnf --setopt=repo_gpgcheck=1 list\" returned an error status.\n- One or more of your repos may not support GPG checking.\n- Configured repos should be validated and repo_gpgcheck enabled where possible." | tee -a "$LOG" 2>> "$ELOG"
			l_test="manual"
		fi

		echo -e "- End remediation - Ensure repo_gpgcheck is globally activated" | tee -a "$LOG" 2>> "$ELOG"
	}

	fed_ensure_repo_gpgcheck_globally_activated_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
        fed_ensure_repo_gpgcheck_globally_activated_fix
		if [ "$l_test" != "manual" ]; then
			fed_ensure_repo_gpgcheck_globally_activated_chk
			if [ "$?" = "101" ]; then
				[ "$l_test" != "failed" ] && l_test="remediated"
			else
				l_test="failed"
			fi
		fi
    fi

	case "$l_test" in
        passed)
            echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-101}"
            ;;
        remediated)
            echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-103}"
            ;;
        manual)
            echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-106}"
            ;;
        NA)
            echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-104}"
            ;;
        *)
            echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-102}"
            ;;
    esac
}