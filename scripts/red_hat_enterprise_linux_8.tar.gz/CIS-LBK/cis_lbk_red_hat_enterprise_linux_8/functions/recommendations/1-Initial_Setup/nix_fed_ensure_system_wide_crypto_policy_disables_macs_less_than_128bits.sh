#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_system_wide_crypto_policy_disables_macs_less_than_128bits.sh
#
# 
# Name              Date        Description
# ------------------------------------------------------------------------------------------------
# Randie Bejar      10/16/23    Recommendation "Ensure system wide crypto policy disables macs less than 128 bits"
# Randie Bejar      11/21/23    Update to chk     

fed_ensure_system_wide_crypto_policy_disables_macs_less_than_128bits()
{
    echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
    l_test=""

    fed_ensure_system_wide_crypto_policy_disables_macs_less_than_128bits_chk()
    {
        echo -e "- Start check - Ensure system wide crypto policy disables macs less than 128 bits" | tee -a "$LOG" 2>> "$ELOG"
        l_output=""

        # Verify weak MACs are disabled    
        if grep -Pi -- '^\h*mac\h*=\h*([^#\n\r]+)?-64\b' /etc/crypto-policies/state/CURRENT.pol; then
            echo -e "- System wide crypto policy disables macs less than 128 bits" | tee -a "$LOG" 2>> "$ELOG"
            l_output="passed"
        else
            echo -e "- System wide crypto policy ALLOWS macs less than 128 bits" | tee -a "$LOG" 2>> "$ELOG"
            l_output="failed"    
        fi

        if [ "$l_output" = "passed" ]; then
            echo -e "- PASS: system wide crypto policy disables macs less than 128 bits" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure system wide crypto policy disables macs less than 128 bits" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-101}"
        else
            echo -e "- FAIL: system wide crypto policy enables macs less than 128 bits" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure system wide crypto policy disables macs less than 128 bits" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-102}" 
        fi       
    }

    fed_ensure_system_wide_crypto_policy_disables_macs_less_than_128bits_fix()
    {
        echo -e "- Start remediation - Ensure system wide crypto policy disables macs less than 128 bits" | tee -a "$LOG" 2>> "$ELOG"

        # Create NO-WEAKMAC.pmod
        echo -e "- Creating NO-WEAKMAC.pmod" | tee - a "$LOG" 2>> "$ELOG"
        echo -e "# This is a subpolicy to disable weak macs\nmac = -*-64" > /etc/crypto-policies/policies/modules/NO-WEAKMAC.pmod

        # Update the crypto policy
        update-crypto-policies --set DEFAULT:NO-SHA1:NO-SSHCBC:NO-WEAKMAC

        echo "- Reboot required for cryptographic settings to be effective" | tee -a "$LOG" 2>> "$ELOG"
        l_test="manual"

        echo -e "- End remediation - Ensure system wide crypto policy disables macs less than 128 bits" | tee -a "$LOG" 2>> "$ELOG"

    }

    fed_ensure_system_wide_crypto_policy_disables_macs_less_than_128bits_chk
    if [ "$?" = "101" ]; then
        [ -z "$l_test" ] && l_test="passed"
    else
        fed_ensure_system_wide_crypto_policy_disables_macs_less_than_128bits_fix
        if [ "$l_test" != "manual" ]; then
            fed_ensure_system_wide_crypto_policy_disables_macs_less_than_128bits_chk
        fi
    fi   

    # Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac	         
}