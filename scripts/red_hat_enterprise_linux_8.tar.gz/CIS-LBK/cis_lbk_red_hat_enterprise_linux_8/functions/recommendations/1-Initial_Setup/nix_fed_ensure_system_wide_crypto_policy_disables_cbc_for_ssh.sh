#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_system_wide_crypto_policy_disables_cbc_for_ssh.sh
#
# Name              Date        Description
# ------------------------------------------------------------------------------------------------
# Randie Bejar      10/13/23    Recommendation "Ensure system wide crypto policy disables cbc for ssh"
#

fed_ensure_system_wide_crypto_policy_disables_cbc_for_ssh()
{
    echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"

    fed_ensure_system_wide_crypto_policy_disables_cbc_for_ssh_chk()
    {
        echo -e "- Start check - Ensure system wide crypto policy disables cbc for ssh" | tee -a "$LOG" 2>> "$ELOG"
        l_test="" l_output="" l_output2=""

        if grep -Piq -- '^\h*cipher\h*=\h*([^#\n\r]+)?-CBC\b' /etc/crypto-policies/state/CURRENT.pol; then
            if grep -Piq -- '^\h*cipher@(lib|open)ssh(-server|-client)?\h*=\h*' /etc/crypto-policies/state/CURRENT.pol; then
                if ! grep -Piq -- '^\h*cipher@(lib|open)ssh(-server|-client)?\h*=\h*([^#\n\r]+)?-CBC\b' /etc/crypto-policies/state/CURRENT.pol; then
                    l_output="$l_output\n - Cipher Block Chaining (CBC) is disabled for SSH"
                else
                    l_output2="$l_output2\n - Cipher Block Chaining (CBC) is enabled for SSH"
                fi
            else
                l_output2="$l_output2\n - Cipher Block Chaining (CBC) is enabled for SSH"
            fi
        else
            l_output=" - Cipher Block Chaining (CBC) is disabled"
        fi

        if [ -z "$l_output2" ]; then 
            echo -e "\n- PASS: \n$l_output" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure system wide crypto policy disables cbc for ssh" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-101}"
        else
            echo -e "\n- Audit Result:\n  ** FAIL **\n - Reason(s) for audit failure:\n$l_output2\n" | tee -a "$LOG" 2>> "$ELOG"
            [ -n "$l_output" ] && echo -e "\n- Correctly set:\n$l_output\n" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure system wide crypto policy disables cbc for ssh" | tee -a "$LOG" 2>> "$ELOG"
        fi
    }

    fed_ensure_system_wide_crypto_policy_disables_cbc_for_ssh_fix()
    {
        echo -e "- Start remediation - Ensure system wide crypto policy disables cbc for ssh" | tee -a "$LOG" 2>> "$ELOG"

        # Create NO-SSHCBC pmod
        echo -e "- Creating NO-SSHCBC.pmod" | tee -a "$LOG" 2>> "$ELOG"
        echo -e "# This is a subpolicy to disable all CBC mode ciphers\n# for the SSH protocol (libssh and OpenSSH)\ncipher@SSH = -*-CBC" > /etc/crypto-policies/policies/modules/NO-SSHCBC.pmod

        # Set the default crypto policy to use NO-SSHCBC.pmod
        update-crypto-policies --set DEFAULT:NO-SHA1:NO-SSHCBC
        echo "- Reboot required for cryptographic settings to be effective" | tee -a "$LOG" 2>> "$ELOG"
        l_test="manual"

        echo -e "- End remediation - Ensure system wide crypto policy disables CBC for SSH" | tee -a "$LOG" 2>> "$ELOG"
    }

    fed_ensure_system_wide_crypto_policy_disables_cbc_for_ssh_chk
    if [ "$?" = "101" ]; then 
        [ -z "$l_test" ] && l_test="passed"
    else
        fed_ensure_system_wide_crypto_policy_disables_cbc_for_ssh_fix
        if [ "$l_test" != "manual" ]; then
            fed_ensure_system_wide_crypto_policy_disables_cbc_for_ssh_chk
        fi
    fi

    # Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac	            
}