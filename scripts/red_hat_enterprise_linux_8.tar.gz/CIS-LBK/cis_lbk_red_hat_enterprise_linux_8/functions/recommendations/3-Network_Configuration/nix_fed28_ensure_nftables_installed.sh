#!/usr/bin/env bash

#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed28_ensure_nftables_installed.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       05/18/22    Recommendation "Ensure nftables is installed"
# Randie Bejar 		 11/20/23 	 Changed for Fed28 - removed IPTables from firewall options

fed28_ensure_nftables_installed()
{
		
	# Start recommendation entirely for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	test=""
	
	fed28_ensure_nftables_installed_chk()
	{
		echo "- Start check - Ensure nftables is installed" | tee -a "$LOG" 2>> "$ELOG"
		l_output="" l_output2="" l_fwd_status="" l_nft_status="" l_fwutil_status=""

        # Determine FirewallD utility Status
        $G_PQ firewalld > /dev/null 2>&1 && l_fwd_status="$(systemctl is-enabled firewalld.service):$(systemctl is-active firewalld.service)"

        # Determine NFTables utility Status
        $G_PQ nftables > /dev/null 2>&1 && l_nft_status="$(systemctl is-enabled nftables.service):$(systemctl is-active nftables.service)"

        l_fwutil_status="$l_fwd_status:$l_nft_status"

        case $l_fwutil_status in
            enabled:active:masked:inactive|enabled:active:disabled:inactive)
                l_output="\n - FirewallD utility is in use, enabled and active\n - NFTables utility is correctly disabled or masked and inactive"
				test="NA" ;;
            masked:inactive:enabled:active|disabled:inactive:enabled:active)
                l_output="\n - NFTables utility is in use, enabled and active\n - FirewallD utility is correctly disabled or masked and inactive" ;;
            enabled:active:enabled:active)
                l_output2="\n - Both FirewallD and NFTables utilities are enabled and active" ;;
            enabled:*:enabled:*)
                l_output2="\n - Both FirewallD and NFTables utilities are enabled" ;;
            *:active:*:active)
                l_output2="\n - Both FirewallD and NFTables utilities are enabled" ;;
            :enabled:active)
                l_output="\n - NFTables utility is in use, enabled, and active\n - FirewallD package is not installed" ;;
            :)
                l_output2="\n - Neither FirewallD or NFTables is installed." ;;
            *:*:)
                l_output2="\n - NFTables package is not installed on the system" ;;
            *)
                l_output2="\n - Unable to determine firewall state" ;;
        esac

		if [ -z "$l_output2" ] && [ "$test" = "NA" ]; then
			echo -e "\n - Firewalld is in use echo - Recommendation is non applicable" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "-  End check - Ensure nftables is installed" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
        elif [ -z "$l_output2" ]; then
            echo -e "\n- Audit Results:\n ** Pass **\n$l_output\n"
            echo -e "- PASSED:\n- Ensure nftables is installed" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "-  End check - Ensure nftables is installed" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
        else
            echo -e "\n- Audit Results:\n ** Fail **\n$l_output2\n"
            echo -e "- FAILED:\n- Ensure nftables is installed" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "-  End check - Ensure nftables is installed" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-102}"
        fi
	}
	
	fed28_ensure_nftables_installed_fix()
	{
		echo -e "- Start remediation - Ensure nftables is installed" | tee -a "$LOG" 2>> "$ELOG"
		$G_PM -y install nftables
        systemctl start nftables
		systemctl enable nftables
		echo -e "- End remediation - Ensure nftables is installed" | tee -a "$LOG" 2>> "$ELOG"
	}

		fed28_ensure_nftables_installed_chk
		if [ "$?" = "101" ]; then
			[ -z "$test" ] && test="passed"
		else
			fed28_ensure_nftables_installed_fix
			fed28_ensure_nftables_installed_chk
			if [ "$?" = "101" ]; then
				[ "$test" != "failed" ] && test="remediated"
			fi
		fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}
